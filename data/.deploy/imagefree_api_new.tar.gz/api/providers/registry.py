"""模型注册表：统一收集各提供商 ModelSpec，暴露 /v1/models 与路由查找。

命名契约：外部模型 id = "<provider前缀>/<上游真实模型名>"，让 API/前端用户一目了然
上游来源。例：minimaxh3/nano-banana-pro、aifreeforever/gpt-image-2、nanobanana/nano-banana-pro。
"""
from __future__ import annotations

import logging

from .base import ModelSpec, Provider
from . import imagefree
from . import minimaxh3
from . import aifreeforever
from . import nanobanana

log = logging.getLogger("registry")


class Registry:
    def __init__(self) -> None:
        self.providers: dict[str, Provider] = {}
        self._models: dict[str, ModelSpec] = {}
        self._booted = False

    def _ensure_booted(self) -> None:
        if not self._booted:
            bootstrap()
            self._booted = True

    def register(self, provider: Provider) -> None:
        self.providers[provider.prefix] = provider
        for mid, spec in provider.models.items():
            self._models[mid] = spec
        log.info("注册提供商 %s（%d 模型）", provider.prefix, len(provider.models))

    def model(self, model_id: str) -> ModelSpec | None:
        self._ensure_booted()
        return self._models.get(model_id)

    def provider_for(self, model_id: str) -> Provider | None:
        self._ensure_booted()
        spec = self._models.get(model_id)
        if not spec:
            return None
        return self.providers.get(spec.provider)

    def all_models(self) -> list[ModelSpec]:
        self._ensure_booted()
        return list(self._models.values())

    def grouped(self) -> dict[str, list[dict]]:
        """按提供商分组，供 /v1/models 与前端展示。"""
        self._ensure_booted()
        out: dict[str, list[dict]] = {}
        for m in self._models.values():
            out.setdefault(m.provider, []).append({
                "id": m.id,
                "name": m.display_name or m.upstream_model,
                "upstream_model": m.upstream_model,
                "capabilities": list(m.capabilities),
                "aspect_ratios": list(m.aspect_ratios),
                "resolutions": list(m.resolutions),
                "credits": m.credits,
                "account_required": m.account_required,
                "description": m.description,
            })
        return out

    def provider_summary(self) -> dict[str, dict]:
        """每个提供商的看板摘要（状态/能力/模型数/额度），前端与 healthz 用。"""
        self._ensure_booted()
        out = {}
        for prefix, p in self.providers.items():
            out[prefix] = {
                "display_name": p.display_name,
                "base_url": p.base_url,
                "capabilities": [c for c in ("txt2img", "img2img", "txt2vid", "img2vid") if p.supports(c)],
                "model_count": sum(1 for m in self._models.values() if m.provider == prefix),
                "needs_account": p.needs_account(),
                "needs_proxy_per_request": p.needs_proxy_per_request(),
            }
        return out


# 模块级单例（main 启动时调用 bootstrap 加载各提供商）
registry = Registry()


def bootstrap() -> None:
    """创建并注册全部提供商实例（幂等）。"""
    if registry.providers:
        return
    registry.register(imagefree.ImagefreeProvider())
    registry.register(minimaxh3.Minimaxh3Provider())
    registry.register(aifreeforever.AifreeforeverProvider())
    registry.register(nanobanana.NanobananaProvider())


async def startup_all() -> None:
    bootstrap()
    for p in registry.providers.values():
        try:
            await p.startup()
        except Exception as e:
            log.warning("提供商 %s 启动失败（可忽略，降级）: %s", p.prefix, e)


async def shutdown_all() -> None:
    for p in registry.providers.values():
        try:
            await p.shutdown()
        except Exception as e:
            log.warning("提供商 %s 停止失败: %s", p.prefix, e)
