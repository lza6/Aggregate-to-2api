"""多提供商共享代理池：住宅代理（文件）+ 免费代理（抓取器）双源 + 每 IP 24h 冷却重置。

需求（逆向确认）：aifreeforever 每 IP 每日限额，429 冷却递增，约 24h 重置 → 每请求必须
用不同出口 IP。号池注册也需轮换 IP 防批量风控。

设计：
- 双源：住宅代理文件（每行 http://user:pass@host:port，kookeey 格式，优先）+ 免费代理
  （free_proxy_fetcher 后台抓取注入，source="free"，量大兜底）。
- 分配：最少最近使用（LRU）+ 强制轮换——同一 IP 两次分配之间尽量拉开，避免连续请求撞墙。
- 状态：每 IP 记 {last_used_at, daily_uses, cooldown_until}；429 冷却进入 cooldown；
  24h 后 daily_uses 清零（每日限额重置）。
- 观测：snapshot 只暴露 host:port（不泄漏住宅代理 user:pass 凭据）。
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import time
from urllib.parse import urlsplit

log = logging.getLogger("proxy_pool")

# 冷却 / 每日限额
DAILY_WINDOW = 24 * 3600
COOLDOWN_SECONDS = int(os.getenv("IF_PROXY_COOLDOWN_SECONDS", "120"))


def _safe_url(url: str) -> str:
    """观测面脱敏：只暴露 host:port，不泄漏 user:pass 凭据。"""
    try:
        u = urlsplit(url)
        host = u.hostname or url
        return f"{host}:{u.port}" if u.port else host
    except (ValueError, TypeError):
        return hashlib.sha256(url.encode("utf-8", "replace")).hexdigest()[:12]


class ProxyEntry:
    __slots__ = ("url", "source", "added_at", "last_used_at", "daily_uses", "day_key",
                 "cooldown_until", "consecutive_fails")

    def __init__(self, url: str, source: str = "residential") -> None:
        self.url = url
        self.source = source          # residential | free
        self.added_at = time.time()   # 注入时间（免费代理生命周期用）
        self.last_used_at = 0.0
        self.daily_uses = 0
        self.day_key = ""
        self.cooldown_until = 0.0
        self.consecutive_fails = 0

    def available(self, now: float) -> bool:
        # 冷却中不可用
        if now < self.cooldown_until:
            return False
        # 新的一天 → 每日计数清零（24h 重置）
        day = int(now / DAILY_WINDOW)
        if day != self.day_key:
            self.day_key = day
            self.daily_uses = 0
            self.consecutive_fails = 0
        return True

    def snapshot(self) -> dict:
        return {
            "url": _safe_url(self.url),
            "source": self.source,
            "daily_uses": self.daily_uses,
            "cooldown_seconds": max(0, int(self.cooldown_until - time.time())),
            "fails": self.consecutive_fails,
        }


class ProxyPool:
    def __init__(self, proxy_file: str = "") -> None:
        self.entries: list[ProxyEntry] = []
        self._idx = 0
        if proxy_file:
            self.load_file(proxy_file)

    def load_file(self, path: str) -> int:
        try:
            with open(path, encoding="utf-8") as f:
                urls = [l.strip() for l in f if l.strip() and not l.startswith("#")]
        except OSError as e:
            log.warning("代理文件不可读 %s: %s", path, e)
            return 0
        seen = {e.url for e in self.entries}
        added = 0
        for u in urls:
            if u not in seen:
                self.entries.append(ProxyEntry(u, source="residential"))
                seen.add(u)
                added += 1
        log.info("代理池加载 %d 个（新增 %d）", len(self.entries), added)
        return added

    def add_free(self, urls: list[str]) -> int:
        """批量注入免费代理（去重，source="free"）。返回新增数。"""
        seen = {e.url for e in self.entries}
        added = 0
        for u in urls:
            if u not in seen:
                self.entries.append(ProxyEntry(u, source="free"))
                seen.add(u)
                added += 1
        if added:
            log.info("免费代理注入 %d 个（池总数 %d）", added, len(self.entries))
        return added

    def reap_free(self) -> int:
        """剔除「注入超 1h 且最近 10 分钟未使用」的免费代理（M8 修复）。

        避免无条件 1h 剔除造成 churn + 冷却永不生效：保留刚被使用/最近活跃的
        （last_used_at > added_at 或 last_used_at 距今 <10min），它们可能正被轮换到。
        """
        now = time.time()
        keep = []
        for e in self.entries:
            if e.source == "free" and now - e.added_at > 3600 and now - e.last_used_at > 600:
                continue  # 陈旧且长期未用 → 剔除
            keep.append(e)
        removed = len(self.entries) - len(keep)
        self.entries = keep
        if removed:
            log.info("剔除过期免费代理 %d 个", removed)
        return removed

    @property
    def enabled(self) -> bool:
        return bool(self.entries)

    def acquire(self, force_rotate: bool = True, prefer_source: str | None = None) -> str | None:
        """分配一个可用出口代理。

        force_rotate=True：尽量选「最久未用」的 IP（轮换），避免同一 IP 连续请求。
        prefer_source="residential" 时优先住宅代理（免费兜底）。全在冷却 → 返回最近冷却结束的。
        """
        if not self.entries:
            return None
        now = time.time()
        candidates = [e for e in self.entries if e.available(now)]
        if prefer_source and candidates:
            pref = [e for e in candidates if e.source == prefer_source]
            if pref:
                candidates = pref
        if candidates:
            if force_rotate:
                pick = min(candidates, key=lambda e: e.last_used_at)  # 最久未用优先
            else:
                pick = self.entries[self._idx % len(self.entries)]
                self._idx += 1
        else:
            # 全部冷却 → 选冷却最早结束的
            pick = min(self.entries, key=lambda e: e.cooldown_until)
        pick.last_used_at = now
        pick.daily_uses += 1
        return pick.url

    def mark_failure(self, url: str, rate_limited: bool = True) -> None:
        """请求失败：冷却该 IP；429 则冷却 COOLDOWN_SECONDS（递增）。"""
        for e in self.entries:
            if e.url == url:
                e.consecutive_fails += 1
                if rate_limited:
                    e.cooldown_until = time.time() + COOLDOWN_SECONDS * e.consecutive_fails
                else:
                    e.cooldown_until = time.time() + 30
                return

    def mark_success(self, url: str) -> None:
        for e in self.entries:
            if e.url == url:
                e.consecutive_fails = 0
                return

    def snapshot(self) -> dict:
        return {
            "total": len(self.entries),
            "residential": sum(1 for e in self.entries if e.source == "residential"),
            "free": sum(1 for e in self.entries if e.source == "free"),
            "available": sum(1 for e in self.entries if e.available(time.time())),
            "cooldown": sum(1 for e in self.entries if time.time() < e.cooldown_until),
            "top": [e.snapshot() for e in self.entries[:20]],
        }


# 模块级单例（main 启动时 load_file / free_proxy_fetcher.start）
proxy_pool = ProxyPool()
