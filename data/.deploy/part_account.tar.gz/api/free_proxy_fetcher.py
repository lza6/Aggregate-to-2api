"""免费代理池抓取器：从纯 API 免费源抓取、解析、预检并注入共享 ProxyPool。

低成本住宅代理替代——尤其 aifreeforever「每 IP 每日限额、24h 重置、每请求轮换 IP」
的场景，免费代理量足够大时非常合适。架构（借鉴 chatgpt2api free_proxy_fetcher）：

  asyncio 后台循环 → 4 源抓取（proxyscrape / geonode / proxy-list.download / proxifly github）
  → parse_* 解析去重 → TCP 连通性预检 → ProxyPool.add_free()
  → 周期刷新（默认 30 分钟）+ 失效剔除（预检失败的免费代理移出）

安全红线：免费代理无凭据但有数据泄露风险（明文 http）。仅用于图像生成/注册类非敏感调用，
IF_FREE_PROXY 默认关闭（零副作用）；开启才工作。
"""
from __future__ import annotations

import asyncio
import ipaddress
import json
import logging
import os
import time

import httpx

from . import config
# 注意：proxy_pool 模块内定义了单例实例 proxy_pool，须导入实例本体
from .proxy_pool import proxy_pool

log = logging.getLogger("free_proxy")

# 抓取超时
FETCH_TIMEOUT = 15.0
# 连通性预检超时（TCP 连接）
PRECHECK_TIMEOUT = 3.0

# 免费代理源（name, url, format: ipport|json）
FREE_PROXY_SOURCES = [
    {
        "name": "proxyscrape",
        "url": ("https://api.proxyscrape.com/v2/?request=getproxies"
                "&protocol=http&timeout=5000&country=all&ssl=yes&anonymity=all"),
        "format": "ipport",
    },
    {
        "name": "geonode",
        "url": ("https://proxylist.geonode.com/api/proxy-list?limit=200&page=1"
                "&sort_by=lastChecked&sort_type=desc&protocols=http"),
        "format": "json",
    },
    {
        "name": "proxy-list-download",
        "url": "https://www.proxy-list.download/api/v1/get?type=http",
        "format": "ipport",
    },
    {
        "name": "proxifly-github",
        "url": "https://raw.githubusercontent.com/proxifly/free-proxy-list/main/proxies/all/data.txt",
        "format": "ipport",
    },
]


def _is_valid_public_ip(host: str) -> bool:
    """过滤内网/回环/链路本地/保留/多播地址（H5 安全修复：防恶意代理源注入内网地址）。

    免费代理源只应是公网 IP:port；hostname 一律拒绝（源都是纯 IP）。
    """
    try:
        addr = ipaddress.ip_address(host)
    except ValueError:
        return False  # 非合法 IP（hostname 等）→ 拒绝
    return not (addr.is_private or addr.is_loopback or addr.is_link_local
                or addr.is_reserved or addr.is_multicast or addr.is_unspecified)


def parse_ipport_text(text: str) -> list[str]:
    """解析 ip:port 文本行，返回 url 列表（去重）。仅保留公网 IPv4/IPv6。"""
    seen: set[str] = set()
    out: list[str] = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.count(":") != 1:
            continue
        host, port = line.rsplit(":", 1)
        if not host or not port.isdigit():
            continue
        if not _is_valid_public_ip(host):
            continue
        url = f"http://{host}:{port}"
        if url in seen:
            continue
        seen.add(url)
        out.append(url)
    return out


def parse_geonode_json(text: str) -> list[str]:
    """解析 geonode JSON（data[].ip/port），返回 url 列表（去重）。仅保留公网 IP。"""
    try:
        data = json.loads(text or "")
    except (ValueError, TypeError):
        return []
    items = data.get("data") if isinstance(data, dict) else None
    if not isinstance(items, list):
        return []
    seen: set[str] = set()
    out: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        ip = str(item.get("ip") or "").strip()
        port = str(item.get("port") or "").strip()
        if not ip or not port.isdigit():
            continue
        if not _is_valid_public_ip(ip):
            continue
        url = f"http://{ip}:{port}"
        if url in seen:
            continue
        seen.add(url)
        out.append(url)
    return out


def parse_source(payload: str, fmt: str) -> list[str]:
    if fmt == "ipport":
        return parse_ipport_text(payload)
    if fmt == "json":
        return parse_geonode_json(payload)
    return []


async def _precheck(url: str) -> bool:
    """TCP 连通性预检：能连上代理端口即可用（不做真实转发验证）。"""
    host, _, port = url.partition("://")[2].rpartition(":")
    try:
        _, writer = await asyncio.wait_for(
            asyncio.open_connection(host, int(port)), timeout=PRECHECK_TIMEOUT)
        writer.close()
        try:
            await asyncio.wait_for(writer.wait_closed(), timeout=1.0)
        except Exception:
            pass
        return True
    except Exception:
        return False


class FreeProxyFetcher:
    """免费代理后台抓取循环（asyncio 单任务）。"""

    def __init__(self, pool) -> None:
        self.pool = pool
        self.task: asyncio.Task | None = None
        self.stats: dict = {"sources_ok": 0, "fetched": 0, "injected": 0, "last_at": 0.0}
        self._client: httpx.AsyncClient | None = None

    async def start(self) -> None:
        if not config.FREE_PROXY_ENABLED:
            return
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(FETCH_TIMEOUT),
                                         headers={"User-Agent": config.USER_AGENT},
                                         proxy=config.PROXY)
        self.task = asyncio.create_task(self._loop())
        log.info("免费代理抓取循环已启动")

    async def stop(self) -> None:
        if self.task:
            self.task.cancel()
            try:
                await self.task
            except asyncio.CancelledError:
                pass
        if self._client:
            await self._client.aclose()
            self._client = None

    async def _loop(self) -> None:
        while True:
            try:
                self.stats = await self._fetch_once()
                log.info("免费代理抓取: sources_ok=%d fetched=%d injected=%d",
                         self.stats["sources_ok"], self.stats["fetched"], self.stats["injected"])
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("免费代理抓取异常: %s", e)
            await asyncio.sleep(config.FREE_PROXY_REFRESH_MIN * 60)

    async def _fetch_once(self) -> dict:
        assert self._client is not None
        sources_ok = fetched = 0
        candidates: list[str] = []
        for src in FREE_PROXY_SOURCES:
            try:
                r = await self._client.get(src["url"])
                if r.status_code != 200:
                    continue
                urls = parse_source(r.text, src["format"])
                if urls:
                    sources_ok += 1
                    fetched += len(urls)
                    candidates.extend(urls)
            except Exception as e:
                log.debug("免费代理源 %s 抓取失败: %s", src["name"], e)
        # 去重 + 预检（并发，限 20 个并行）
        seen: set[str] = set()
        unique = []
        for u in candidates:
            if u not in seen:
                seen.add(u)
                unique.append(u)
        healthy: list[str] = []
        sem = asyncio.Semaphore(20)

        async def _check(u: str) -> bool:
            async with sem:
                return await _precheck(u)

        results = await asyncio.gather(*(_check(u) for u in unique[:300]))
        healthy = [u for u, ok in zip(unique[:300], results) if ok]
        injected = self.pool.add_free(healthy)
        # 失效/过期免费代理剔除
        self.pool.reap_free()
        # L7(审计修复): fetched 只统计实际预检的候选数（与注入口径一致），不虚高
        return {"sources_ok": sources_ok, "fetched": len(unique[:300]), "injected": injected,
                "last_at": time.time()}


# 模块级单例（main 启动时 start()）
free_proxy_fetcher = FreeProxyFetcher(proxy_pool)
