"""SQLite 持久化：请求记录、按日/月统计、画廊、并发计数。

选 SQLite（标准库，WAL 模式）而非 JSON：50 RPS 高频写 + 并发读下，
JSON 整文件重写有锁竞争；SQLite 单行 INSERT 毫秒级，WAL 支持读写并行。
写入用 threading.Lock 串行化（单连接安全），读不加锁（WAL 快照隔离）。

时间戳用 Unix 秒（UTC）；日/月分组用 'localtime' 适配服务器本地时区。
"""
import json
import logging
import os
import sqlite3
import threading
import time

log = logging.getLogger("db")


class DB:
    def __init__(self, path: str):
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row  # 便于按列名取值，避免 SELECT * 列序依赖
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA busy_timeout=5000")
        self._lock = threading.Lock()
        self._init_schema()

    # ── 结构 ──────────────────────────────────────
    def _init_schema(self) -> None:
        with self._lock:
            self._conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS requests (
                    id          TEXT PRIMARY KEY,
                    prompt      TEXT,
                    aspect_ratio TEXT,
                    download    INTEGER DEFAULT 0,
                    status      TEXT,
                    image_url   TEXT,
                    image_base64 TEXT,
                    image_mime  TEXT,
                    error       TEXT,
                    created_at  REAL,
                    started_at  REAL,
                    finished_at REAL,
                    duration_sec REAL
                );
                CREATE INDEX IF NOT EXISTS idx_requests_created ON requests(created_at);
                CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
                -- H5: 画廊按 finished_at 倒序查询，建索引避免全表扫描
                CREATE INDEX IF NOT EXISTS idx_requests_finished ON requests(finished_at);
                """
            )
            # 存量表迁移：旧库缺列则补齐（type=任务类型 txt/img，model=风格预设 id，
            # upstream_task_id=上游生成任务 id，便于恢复孤儿槽位/排查）
            cols = {r[1] for r in self._conn.execute("PRAGMA table_info(requests)")}
            for col, ddl in (("image_base64", "TEXT"), ("image_mime", "TEXT"),
                             ("type", "TEXT DEFAULT 'txt'"), ("model", "TEXT DEFAULT 'default'"),
                             ("upstream_task_id", "TEXT")):
                if col not in cols:
                    self._conn.execute(f"ALTER TABLE requests ADD COLUMN {col} {ddl}")
            self._conn.commit()

    # ── 写 ────────────────────────────────────────
    def create_request(self, task_id: str, prompt: str, aspect_ratio: str, download: bool,
                       type_: str = "txt", model: str = "default") -> None:
        with self._lock:
            self._conn.execute(
                "INSERT INTO requests (id, prompt, aspect_ratio, download, status, created_at, type, model)"
                " VALUES (?, ?, ?, ?, 'pending', ?, ?, ?)",
                (task_id, prompt, aspect_ratio, int(download), time.time(), type_, model),
            )
            self._conn.commit()

    def mark_started(self, task_id: str) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE requests SET status='processing', started_at=? WHERE id=?",
                (time.time(), task_id),
            )
            self._conn.commit()

    def mark_finished(self, task_id: str, status: str, image_url: str | None,
                      error: str | None, duration_sec: float | None,
                      image_base64: str | None = None, image_mime: str | None = None) -> None:
        with self._lock:
            self._conn.execute(
                "UPDATE requests SET status=?, image_url=?, image_base64=?, image_mime=?,"
                " error=?, finished_at=?, duration_sec=? WHERE id=?",
                (status, image_url, image_base64, image_mime, error, time.time(),
                 duration_sec, task_id),
            )
            self._conn.commit()

    def update_upstream_task(self, task_id: str, upstream_task_id: str) -> None:
        """记录上游生成任务 id（图生图/文生图均可），便于恢复孤儿槽位与排查。"""
        with self._lock:
            self._conn.execute(
                "UPDATE requests SET upstream_task_id=? WHERE id=?",
                (upstream_task_id, task_id),
            )
            self._conn.commit()

    def recover_stale_tasks(self, reason: str = "服务重启，任务中断",
                            stale_after: float = 300.0) -> int:
        """启动时回收上次进程遗留的 pending/processing 孤儿任务（H4）。

        新进程内存队列为空，此刻 DB 里所有 pending/processing 都来自崩溃/重启前的旧进程，
        永远不会再被消费，标记为 error 防止统计失真、防止前端永久 pending。
        stale_after 时间门槛：只回收创建超过该秒数的陈旧任务，避免多进程部署下
        误伤其它进程刚入队/正在处理的任务（MEDIUM-2）。
        """
        cutoff = time.time() - stale_after
        with self._lock:
            cur = self._conn.execute(
                "UPDATE requests SET status='error', error=?, finished_at=? "
                "WHERE status IN ('pending','processing') AND created_at < ?",
                (reason, time.time(), cutoff),
            )
            self._conn.commit()
            return cur.rowcount

    # ── 读 ────────────────────────────────────────
    # 公共 API 响应需要的列（M8：不投影 prompt/download 等内部/大字段）
    _PUBLIC_COLS = (
        "id", "status", "image_url", "image_base64", "image_mime", "error",
        "created_at", "duration_sec", "type", "model",
    )

    def get(self, task_id: str) -> dict | None:
        row = self._conn.execute("SELECT * FROM requests WHERE id=?", (task_id,)).fetchone()
        if not row:
            return None
        return self._row_to_dict(row)

    def get_public(self, task_id: str) -> dict | None:
        """轻量查询：只取公共 API 响应字段（不含 prompt），供 /v1/tasks 等读路径。"""
        cols = ", ".join(self._PUBLIC_COLS)
        row = self._conn.execute(f"SELECT {cols} FROM requests WHERE id=?", (task_id,)).fetchone()
        if not row:
            return None
        return self._row_to_dict(row, default=False)

    def recent_images(self, limit: int = 50) -> list[dict]:
        """画廊：最近完成的、有图的请求。"""
        rows = self._conn.execute(
            "SELECT * FROM requests WHERE status='completed' AND image_url IS NOT NULL"
            " ORDER BY finished_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    def recent_errors(self, limit: int = 20) -> list[dict]:
        """最近失败的请求（含错误原因/prompt），供在线排查，无需 SSH。"""
        rows = self._conn.execute(
            "SELECT * FROM requests WHERE status='error'"
            " ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [self._row_to_dict(r) for r in rows]

    # ── 统计 ──────────────────────────────────────
    def stats_overview(self) -> dict:
        """总量 + 平均出图耗时。"""
        row = self._conn.execute(
            "SELECT COUNT(*) AS total, "
            " SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS images, "
            " SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) AS errors, "
            " AVG(CASE WHEN status='completed' AND duration_sec IS NOT NULL"
            "         THEN duration_sec END) AS avg_duration"
            " FROM requests"
        ).fetchone()
        total, images, errors, avg_duration = row
        return {
            "total_requests": int(total or 0),
            "total_images": int(images or 0),
            "total_errors": int(errors or 0),
            "avg_duration_sec": round(float(avg_duration), 1) if avg_duration else None,
        }

    def stats_daily(self, days: int = 14) -> list[dict]:
        """近 N 天：每天请求/出图/失败。"""
        rows = self._conn.execute(
            "SELECT strftime('%Y-%m-%d', created_at, 'unixepoch', 'localtime') AS day, "
            " COUNT(*) AS total, "
            " SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS images, "
            " SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) AS errors"
            " FROM requests WHERE created_at > ?"
            " GROUP BY day ORDER BY day",
            (time.time() - days * 86400,),
        ).fetchall()
        return [{"day": r[0], "total": r[1], "images": r[2], "errors": r[3]} for r in rows]

    def stats_monthly(self, months: int = 12) -> list[dict]:
        """近 N 月：每月请求/出图/失败。"""
        rows = self._conn.execute(
            "SELECT strftime('%Y-%m', created_at, 'unixepoch', 'localtime') AS month, "
            " COUNT(*) AS total, "
            " SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) AS images, "
            " SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) AS errors"
            " FROM requests WHERE created_at > ?"
            " GROUP BY month ORDER BY month",
            (time.time() - months * 31 * 86400,),
        ).fetchall()
        return [{"month": r[0], "total": r[1], "images": r[2], "errors": r[3]} for r in rows]

    # ── 增长治理（M7）──────────────────────────────
    def cleanup(self, retention_days: int) -> dict:
        """TTL 清理：删除超期请求记录，回收 WAL 并 VACUUM 压缩文件。

        返回 {"deleted", "size_before", "size_after"}。SQLite 单文件 + WAL，
        删除后 wal_checkpoint(TRUNCATE) 回收 WAL，VACUUM 压缩主文件（会重写，低频执行）。
        """
        cutoff = time.time() - retention_days * 86400
        path = self._conn.execute("PRAGMA database_list").fetchone()[2]
        size_before = os.path.getsize(path) if os.path.exists(path) else 0
        with self._lock:
            cur = self._conn.execute(
                "DELETE FROM requests WHERE created_at < ?", (cutoff,))
            self._conn.commit()
            deleted = cur.rowcount
            try:
                self._conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            except sqlite3.OperationalError:
                pass
            try:
                self._conn.execute("VACUUM")
            except sqlite3.OperationalError as e:
                log.warning("VACUUM 失败（可忽略，稍后自动重试）: %s", e)
            self._conn.commit()
        size_after = os.path.getsize(path) if os.path.exists(path) else 0
        return {"deleted": deleted, "size_before": size_before, "size_after": size_after}

    def count(self) -> int:
        """总记录数（指标用）。"""
        return int(self._conn.execute("SELECT COUNT(*) FROM requests").fetchone()[0])

    @staticmethod
    def _row_to_dict(row: sqlite3.Row, default: bool = True) -> dict:
        # 用 row.keys() 而非硬编码列名：旧库 ALTER 加列会改变 SELECT * 顺序，硬编码会错位。
        # default=True: 全行（SELECT *，含 prompt/download 等内部列）；
        # default=False: 投影列（get_public，不含 prompt，避免不必要的字段暴露/传输）。
        keys = row.keys()
        d = dict(zip(keys, row))
        if "download" in d:
            d["download"] = bool(d["download"])
        # M2(审计): 0.0 是合法耗时，用 is not None 判定而非假值，避免 0 秒任务上报 None
        d["duration_sec"] = round(d["duration_sec"], 1) if d.get("duration_sec") is not None else None
        d.setdefault("type", "txt")
        d.setdefault("model", "default")
        d.setdefault("upstream_task_id", None)
        return d


def task_to_public(t: dict) -> dict:
    """数据库行 → API 响应结构。"""
    return {
        "id": t["id"],
        "status": t["status"],
        "image_url": t["image_url"],
        "image_base64": t.get("image_base64"),
        "image_mime": t.get("image_mime"),
        "error": t["error"],
        "created_at": t["created_at"],
        "duration_sec": t["duration_sec"],
        "type": t.get("type", "txt"),
        "model": t.get("model", "default"),
    }
